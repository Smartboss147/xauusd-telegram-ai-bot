import { test } from "node:test";
import assert from "node:assert/strict";
import { analyzeStructure } from "../lib/structure";
import { computeIndicators } from "../lib/indicators";
import { calculateRisk } from "../lib/risk";
import { validateTradePlan, ValidationError } from "../lib/validate";
import { detectIntent, parseRiskArgs } from "../lib/intent";
import { Candle, LiveQuote } from "../lib/types";

function makeUptrendCandles(n: number, start = 2600): Candle[] {
  const candles: Candle[] = [];
  let price = start;
  for (let i = 0; i < n; i++) {
    // gentle zig-zag uptrend so fractal swings actually form
    const wiggle = Math.sin(i / 3) * 1.5;
    const open = price + wiggle;
    const close = open + 0.8;
    const high = Math.max(open, close) + 0.5;
    const low = Math.min(open, close) - 0.5;
    candles.push({ time: 1700000000 + i * 900, open, high, low, close });
    price += 0.6;
  }
  return candles;
}

function fakeQuote(price: number): LiveQuote {
  return {
    symbol: "XAUUSD",
    price,
    bid: null,
    ask: null,
    spread: null,
    timestampUtc: new Date().toISOString(),
    ageSeconds: 1,
    provider: "test",
    marketOpen: true,
  };
}

test("analyzeStructure detects a bullish trend on a rising series", () => {
  const candles = makeUptrendCandles(60);
  const result = analyzeStructure("M15", candles);
  assert.equal(result.trend, "bullish");
  assert.equal(result.candles, 60);
});

test("computeIndicators returns null for insufficient data instead of guessing", () => {
  const shortSeries = makeUptrendCandles(5);
  const ind = computeIndicators(shortSeries);
  assert.equal(ind.ema200, null);
  assert.equal(ind.macd, null);
});

test("computeIndicators produces sane RSI/EMA on a longer uptrend series", () => {
  const candles = makeUptrendCandles(60);
  const ind = computeIndicators(candles);
  assert.ok(ind.rsi14 !== null && ind.rsi14 > 50, "RSI should favor the uptrend");
  assert.ok(ind.ema20 !== null && ind.ema50 !== null);
});

test("calculateRisk computes correct max risk amount", () => {
  const result = calculateRisk({ balance: 500, riskPercent: 1, entry: 2650, stopLoss: 2645 });
  assert.equal(result.maxRiskAmount, 5);
  assert.equal(result.stopLossDistancePips, 5);
});

test("calculateRisk handles identical entry/stop safely", () => {
  const result = calculateRisk({ balance: 500, riskPercent: 1, entry: 2650, stopLoss: 2650 });
  assert.equal(result.suggestedLotSize, null);
});

test("validateTradePlan rejects a BUY with inverted stop/TP", () => {
  const quote = fakeQuote(2650);
  const bad = {
    decision: "BUY",
    bias: "bullish",
    setupType: "test",
    timeframe: "M15",
    entryZoneLow: 2649,
    entryZoneHigh: 2651,
    idealEntry: 2650,
    entryTrigger: "test trigger",
    stopLoss: 2655, // wrong side for a BUY
    takeProfit1: 2660,
    takeProfit2: null,
    takeProfit3: null,
    riskReward: 2,
    invalidation: "test invalidation",
    setupScore: 80,
    confidence: "high",
    newsRisk: "low",
    marketCondition: "trending",
    reasoning: "test",
    structureSummary: "test",
    liquiditySummary: "test",
    momentumSummary: "test",
  };
  assert.throws(() => validateTradePlan(bad, quote), ValidationError);
});

test("validateTradePlan rejects an implausible hallucinated price", () => {
  const quote = fakeQuote(2650);
  const bad = {
    decision: "SELL",
    bias: "bearish",
    setupType: "test",
    timeframe: "M15",
    entryZoneLow: 100,
    entryZoneHigh: 105,
    idealEntry: 100, // wildly off from live price of 2650
    entryTrigger: "test trigger",
    stopLoss: 110,
    takeProfit1: 90,
    takeProfit2: null,
    takeProfit3: null,
    riskReward: 2,
    invalidation: "test invalidation",
    setupScore: 80,
    confidence: "high",
    newsRisk: "low",
    marketCondition: "trending",
    reasoning: "test",
    structureSummary: "test",
    liquiditySummary: "test",
    momentumSummary: "test",
  };
  assert.throws(() => validateTradePlan(bad, quote), ValidationError);
});

test("validateTradePlan accepts a well-formed WAIT with null price fields", () => {
  const quote = fakeQuote(2650);
  const ok = {
    decision: "WAIT",
    bias: "neutral",
    setupType: null,
    timeframe: null,
    entryZoneLow: null,
    entryZoneHigh: null,
    idealEntry: null,
    entryTrigger: "Wait for M5 confirmation.",
    stopLoss: null,
    takeProfit1: null,
    takeProfit2: null,
    takeProfit3: null,
    riskReward: null,
    invalidation: "N/A while waiting.",
    setupScore: 40,
    confidence: "low",
    newsRisk: "medium",
    marketCondition: "choppy",
    reasoning: "Conflicting structure across timeframes.",
    structureSummary: "mixed",
    liquiditySummary: "none clear",
    momentumSummary: "flat",
  };
  const plan = validateTradePlan(ok, quote);
  assert.equal(plan.decision, "WAIT");
  assert.equal(plan.stopLoss, null);
});

test("detectIntent recognizes natural language analysis requests", () => {
  assert.equal(detectIntent("Should I buy or sell gold?"), "analyze");
  assert.equal(detectIntent("Analyze XAUUSD on M5 and M15"), "analyze");
  assert.equal(detectIntent("/status"), "status");
  assert.equal(detectIntent("what's the news today"), "news");
});

test("parseRiskArgs extracts numbers from natural language", () => {
  const args = parseRiskArgs("My balance is $500 and I want to risk 1%, entry 2650, stop 2645");
  assert.deepEqual(args, { balance: 500, riskPercent: 1, entry: 2650, stopLoss: 2645 });
});

test("parseRiskArgs extracts numbers from slash command", () => {
  const args = parseRiskArgs("/risk 500 1 2650 2645");
  assert.deepEqual(args, { balance: 500, riskPercent: 1, entry: 2650, stopLoss: 2645 });
});
