import type { VercelRequest, VercelResponse } from "@vercel/node";

// Minimal, unauthenticated health check for uptime pings / sanity checks.
// Intentionally reveals nothing about configuration state or secrets —
// for a real status readout with live checks, message the bot /status on
// Telegram instead (that one is authorized via TELEGRAM_ALLOWED_USER_ID).
export default function handler(_req: VercelRequest, res: VercelResponse) {
  res.status(200).json({
    ok: true,
    service: "xauusd-telegram-ai-bot",
    mode: "stateless-serverless",
    database: "none",
    memory: "disabled",
  });
}
