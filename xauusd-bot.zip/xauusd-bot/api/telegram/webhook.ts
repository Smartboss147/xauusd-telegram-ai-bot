import type { VercelRequest, VercelResponse } from "@vercel/node";
import { sendMessage, verifyTelegramSecret, TelegramUpdate } from "../../lib/telegram";
import { isAuthorized } from "../../lib/auth";
import { detectIntent } from "../../lib/intent";
import {
  runAnalysis,
  runHelp,
  runNewsCheck,
  runRiskCalc,
  runStart,
  runStatus,
} from "../../lib/commands";
import { formatUnauthorized } from "../../lib/format";
import { MissingEnvError } from "../../lib/config";

// Best-effort duplicate-update guard. This lives only in the memory of a
// warm Lambda/Edge instance — it is explicitly NOT persistent storage, and
// is allowed to be empty/reset at any time (cold start, scale-out, etc).
// Re-processing a duplicate update just re-runs a stateless analysis; it
// never causes a double trade because this bot never executes trades.
const seenUpdateIds = new Set<number>();
const MAX_SEEN = 500;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    res.status(200).send("XAUUSD Telegram bot webhook is alive. Use POST for Telegram updates.");
    return;
  }

  if (!verifyTelegramSecret(req.headers["x-telegram-bot-api-secret-token"])) {
    res.status(401).send("Invalid secret token.");
    return;
  }

  const update = req.body as TelegramUpdate;
  if (!update || typeof update !== "object") {
    res.status(400).send("Malformed update.");
    return;
  }

  // Acknowledge Telegram immediately conceptually — we still do the work
  // inline (Vercel functions are request/response, no background workers),
  // but we respond 200 as soon as our own processing completes so Telegram
  // doesn't treat a slow-but-successful analysis as a delivery failure.
  try {
    if (update.update_id != null) {
      if (seenUpdateIds.has(update.update_id)) {
        res.status(200).send("duplicate ignored");
        return;
      }
      seenUpdateIds.add(update.update_id);
      if (seenUpdateIds.size > MAX_SEEN) {
        const first = seenUpdateIds.values().next().value;
        if (first !== undefined) seenUpdateIds.delete(first);
      }
    }

    const message = update.message;
    if (!message || !message.text || !message.chat) {
      res.status(200).send("no-op");
      return;
    }

    const chatId = message.chat.id;
    const userId = message.from?.id;
    const text = message.text;

    if (!isAuthorized(userId)) {
      await sendMessage(chatId, formatUnauthorized());
      res.status(200).send("unauthorized");
      return;
    }

    const intent = detectIntent(text);
    let reply: string;

    switch (intent) {
      case "start":
        reply = runStart();
        break;
      case "help":
        reply = runHelp();
        break;
      case "status":
        reply = await runStatus();
        break;
      case "news":
        reply = await runNewsCheck();
        break;
      case "risk":
        reply = runRiskCalc(text);
        break;
      case "analyze":
      case "bias":
      case "structure":
        reply = await runAnalysis(text);
        break;
      default:
        reply = [
          "I didn't quite catch that. Try:",
          '"Analyze XAUUSD" or /help for everything I can do.',
        ].join("\n");
    }

    await sendMessage(chatId, reply);
    res.status(200).send("ok");
  } catch (e) {
    if (e instanceof MissingEnvError) {
      console.error("Configuration error:", e.varName);
      const message = update.message;
      if (message?.chat?.id) {
        await sendMessage(
          message.chat.id,
          `⚠️ The bot is missing required configuration (${e.varName}). Please contact the operator.`
        ).catch(() => {});
      }
      res.status(200).send("config error handled");
      return;
    }
    console.error("Unhandled webhook error:", e);
    const message = update.message;
    if (message?.chat?.id) {
      await sendMessage(
        message.chat.id,
        "Something went wrong processing your request. Please try again in a moment."
      ).catch(() => {});
    }
    res.status(200).send("error handled");
  }
}
