// Usage: TELEGRAM_BOT_TOKEN=xxx node scripts/webhook-info.js
const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
  console.error("Set TELEGRAM_BOT_TOKEN in your environment first.");
  process.exit(1);
}

async function main() {
  const res = await fetch(`https://api.telegram.org/bot${token}/getWebhookInfo`);
  const json = await res.json();
  console.log(JSON.stringify(json, null, 2));
}

main();
