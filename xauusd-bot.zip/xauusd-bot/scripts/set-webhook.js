// Usage:
//   TELEGRAM_BOT_TOKEN=xxx TELEGRAM_WEBHOOK_SECRET=yyy \
//     node scripts/set-webhook.js https://your-app.vercel.app/api/telegram/webhook
//
// This just calls Telegram's setWebhook endpoint directly — no dependencies.

const token = process.env.TELEGRAM_BOT_TOKEN;
const secret = process.env.TELEGRAM_WEBHOOK_SECRET;
const url = process.argv[2];

if (!token) {
  console.error("Set TELEGRAM_BOT_TOKEN in your environment first.");
  process.exit(1);
}
if (!url) {
  console.error("Usage: node scripts/set-webhook.js <https://your-app.vercel.app/api/telegram/webhook>");
  process.exit(1);
}

async function main() {
  const body = { url };
  if (secret) body.secret_token = secret;

  const res = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = await res.json();
  console.log(JSON.stringify(json, null, 2));
  if (!json.ok) process.exit(1);
}

main();
