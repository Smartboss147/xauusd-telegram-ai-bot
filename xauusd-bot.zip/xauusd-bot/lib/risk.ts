import { RiskCalcInput, RiskCalcResult } from "./types";

/**
 * XAUUSD contract specifications differ by broker (Exness itself offers
 * multiple XAUUSD variants with different contract sizes/leverage tiers).
 * We do NOT assume a specific Exness contract size. Instead we compute the
 * risk amount precisely, and give a position-size estimate ONLY under the
 * most common convention (1 standard lot = 100 oz, so $1 move = $100/lot),
 * clearly labeled as an estimate the user must confirm against their own
 * Exness contract specification (visible in MT5 -> symbol specification).
 */
const ASSUMED_CONTRACT_OZ_PER_LOT = 100;

export function calculateRisk(input: RiskCalcInput): RiskCalcResult {
  const { balance, riskPercent, entry, stopLoss } = input;

  const maxRiskAmount = Number(((balance * riskPercent) / 100).toFixed(2));
  const stopDistance = Math.abs(entry - stopLoss);

  if (stopDistance <= 0) {
    return {
      maxRiskAmount,
      stopLossDistancePips: 0,
      suggestedLotSize: null,
      note: "Entry and stop loss are identical — cannot size a position.",
    };
  }

  const dollarValuePerLotForFullMove = ASSUMED_CONTRACT_OZ_PER_LOT * stopDistance;
  const suggestedLotSize = Number((maxRiskAmount / dollarValuePerLotForFullMove).toFixed(2));

  return {
    maxRiskAmount,
    stopLossDistancePips: Number(stopDistance.toFixed(2)),
    suggestedLotSize,
    note:
      "Lot size assumes a standard 100 oz/lot XAUUSD contract (the common convention). " +
      "Exness may quote a different contract size or use cent/mini variants — verify the " +
      "exact contract specification in MT5 (Symbol → Specification) before sizing a real trade.",
  };
}
