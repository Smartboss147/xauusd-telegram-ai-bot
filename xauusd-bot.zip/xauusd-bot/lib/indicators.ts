import { Candle, IndicatorSnapshot } from "./types";

// All indicators are computed locally from the OHLC candles we already
// fetched for structure analysis. This avoids spending extra Twelve Data
// API credits on separate indicator endpoints and keeps everything
// derived from the exact same dataset (no risk of indicator/candle
// mismatch from two different calls).

function ema(values: number[], period: number): number[] {
  if (values.length === 0) return [];
  const k = 2 / (period + 1);
  const out: number[] = [values[0]];
  for (let i = 1; i < values.length; i++) {
    out.push(values[i] * k + out[i - 1] * (1 - k));
  }
  return out;
}

function lastOrNull(arr: number[]): number | null {
  if (!arr.length) return null;
  const v = arr[arr.length - 1];
  return Number.isFinite(v) ? Number(v.toFixed(2)) : null;
}

function rsi(closes: number[], period = 14): number | null {
  if (closes.length < period + 1) return null;
  let gains = 0;
  let losses = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return Number((100 - 100 / (1 + rs)).toFixed(2));
}

function atr(candles: Candle[], period = 14): number | null {
  if (candles.length < period + 1) return null;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const prevClose = candles[i - 1].close;
    const tr = Math.max(
      c.high - c.low,
      Math.abs(c.high - prevClose),
      Math.abs(c.low - prevClose)
    );
    trs.push(tr);
  }
  const recent = trs.slice(-period);
  const avg = recent.reduce((a, b) => a + b, 0) / recent.length;
  return Number(avg.toFixed(2));
}

function macd(closes: number[]) {
  if (closes.length < 35) return null;
  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const signalLine = ema(macdLine, 9);
  const last = macdLine.length - 1;
  return {
    macd: Number(macdLine[last].toFixed(3)),
    signal: Number(signalLine[last].toFixed(3)),
    histogram: Number((macdLine[last] - signalLine[last]).toFixed(3)),
  };
}

export function computeIndicators(candles: Candle[]): IndicatorSnapshot {
  const closes = candles.map((c) => c.close);
  return {
    ema20: lastOrNull(ema(closes, 20)),
    ema50: lastOrNull(ema(closes, 50)),
    ema200: candles.length >= 200 ? lastOrNull(ema(closes, 200)) : null,
    rsi14: rsi(closes, 14),
    atr14: atr(candles, 14),
    macd: macd(closes),
  };
}
