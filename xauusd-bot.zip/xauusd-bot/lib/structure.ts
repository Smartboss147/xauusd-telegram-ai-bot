import { Candle, StructureSnapshot, SwingPoint, Timeframe } from "./types";

// Fractal swing detection: a candle is a swing high if its high is the
// highest among `lookback` candles on either side, and symmetrically for
// swing lows. This is a standard, deterministic definition (not AI-guessed)
// so structure calls are reproducible from the same candle data.
function findSwings(candles: Candle[], lookback = 2): SwingPoint[] {
  const swings: SwingPoint[] = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    const window = candles.slice(i - lookback, i + lookback + 1);
    const c = candles[i];
    const isHigh = window.every((w) => w.high <= c.high);
    const isLow = window.every((w) => w.low >= c.low);
    if (isHigh) swings.push({ time: c.time, price: c.high, type: "high" });
    else if (isLow) swings.push({ time: c.time, price: c.low, type: "low" });
  }
  return swings;
}

function tolerance(price: number): number {
  // ~0.05% of price — small enough to mean "practically equal" for gold,
  // wide enough to survive normal tick noise.
  return price * 0.0005;
}

export function analyzeStructure(timeframe: Timeframe, candles: Candle[]): StructureSnapshot {
  const swings = findSwings(candles, 2);
  const highs = swings.filter((s) => s.type === "high");
  const lows = swings.filter((s) => s.type === "low");

  const lastClose = candles[candles.length - 1].close;

  let trend: StructureSnapshot["trend"] = "ranging";
  let lastBOS: StructureSnapshot["lastBOS"] = null;
  let lastCHOCH: StructureSnapshot["lastCHOCH"] = null;

  if (highs.length >= 2 && lows.length >= 2) {
    const [prevHigh, curHigh] = highs.slice(-2);
    const [prevLow, curLow] = lows.slice(-2);
    const higherHighs = curHigh.price > prevHigh.price;
    const higherLows = curLow.price > prevLow.price;
    const lowerHighs = curHigh.price < prevHigh.price;
    const lowerLows = curLow.price < prevLow.price;

    if (higherHighs && higherLows) trend = "bullish";
    else if (lowerHighs && lowerLows) trend = "bearish";
    else trend = "ranging";

    // BOS = price continues beyond the most recent swing in the direction
    // of the established trend. CHOCH = price breaks structure against the
    // prevailing trend for the first time (early reversal signal).
    const mostRecentSwingHigh = highs[highs.length - 1];
    const mostRecentSwingLow = lows[lows.length - 1];

    if (trend === "bullish" && lastClose < mostRecentSwingLow.price) {
      lastCHOCH = "bearish";
    } else if (trend === "bearish" && lastClose > mostRecentSwingHigh.price) {
      lastCHOCH = "bullish";
    } else if (lastClose > mostRecentSwingHigh.price) {
      lastBOS = "bullish";
    } else if (lastClose < mostRecentSwingLow.price) {
      lastBOS = "bearish";
    }
  }

  const equalHighs =
    highs.length >= 2 &&
    Math.abs(highs[highs.length - 1].price - highs[highs.length - 2].price) <
      tolerance(lastClose);
  const equalLows =
    lows.length >= 2 &&
    Math.abs(lows[lows.length - 1].price - lows[lows.length - 2].price) < tolerance(lastClose);

  return {
    timeframe,
    trend,
    lastBOS,
    lastCHOCH,
    swingHigh: highs.length ? highs[highs.length - 1].price : null,
    swingLow: lows.length ? lows[lows.length - 1].price : null,
    equalHighs,
    equalLows,
    candles: candles.length,
  };
}
