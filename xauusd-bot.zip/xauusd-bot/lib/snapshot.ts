import { getCandles, getLiveQuote, isQuoteStale, MarketDataError } from "./marketData";
import { computeIndicators } from "./indicators";
import { analyzeStructure } from "./structure";
import { getNewsSnapshot } from "./news";
import { getSession } from "./sessions";
import { MarketSnapshot, NewsSnapshot, Timeframe, TimeframeAnalysis } from "./types";

const TIMEFRAMES: Timeframe[] = ["M5", "M15", "H1", "H4", "D1"];
// M1 and M30 are supported by the types/architecture but omitted from the
// default fetch set to stay comfortably inside Twelve Data's free-tier rate
// limit (8 requests/minute) for a single on-demand analysis: 1 quote + 5
// time_series calls = 6 requests.

export class StaleDataError extends Error {}
export class SnapshotError extends Error {}

export async function buildMarketSnapshot(): Promise<MarketSnapshot> {
  const quote = await getLiveQuote();

  if (isQuoteStale(quote)) {
    throw new StaleDataError(
      `Live price data is ${quote.ageSeconds}s old, which exceeds the freshness threshold.`
    );
  }

  const timeframes: Partial<Record<Timeframe, TimeframeAnalysis>> = {};

  const results = await Promise.allSettled(
    TIMEFRAMES.map(async (tf) => {
      const candles = await getCandles(tf, 150);
      const indicators = computeIndicators(candles);
      const structure = analyzeStructure(tf, candles);
      return { tf, candles, indicators, structure };
    })
  );

  for (const r of results) {
    if (r.status === "fulfilled") {
      const { tf, candles, indicators, structure } = r.value;
      timeframes[tf] = { timeframe: tf, candles, indicators, structure };
    }
  }

  const succeeded = Object.keys(timeframes).length;
  if (succeeded === 0) {
    throw new SnapshotError("Could not retrieve candle data for any timeframe.");
  }

  const news: NewsSnapshot = await getNewsSnapshot().catch(
    (): NewsSnapshot => ({
      available: false,
      events: [],
      highImpactImminent: false,
      reason: "News lookup failed unexpectedly.",
    })
  );

  return {
    quote,
    timeframes,
    news,
    session: getSession(),
  };
}

export { MarketDataError };
