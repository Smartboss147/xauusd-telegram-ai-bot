import { config } from "./config";
import { MarketSnapshot } from "./types";

// Groq offers a genuinely free tier (no credit card, rate-limited rather
// than metered) with fast inference on strong open-weight models — a good
// fit for a personal, on-demand bot where cost needs to stay at $0.
// Model can be overridden via env (AI_MODEL) without a code change if Groq
// changes their free-tier lineup later.
const MODEL = process.env.AI_MODEL || "openai/gpt-oss-120b";
const GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";

export class AIError extends Error {}

function buildFactsPayload(snapshot: MarketSnapshot, userMessage: string) {
  const timeframes: Record<string, unknown> = {};
  for (const [tf, data] of Object.entries(snapshot.timeframes)) {
    if (!data) continue;
    const lastCandles = data.candles.slice(-20); // recent context only
    timeframes[tf] = {
      indicators: data.indicators,
      structure: data.structure,
      recentCandles: lastCandles,
    };
  }

  return {
    symbol: "XAUUSD",
    liveQuote: snapshot.quote,
    timeframes,
    news: snapshot.news,
    session: snapshot.session,
    userMessage,
  };
}

const SYSTEM_PROMPT = `You are a conservative, professional XAUUSD (gold) market analyst.

You are given ONLY structured facts retrieved from a live market data API, computed \
technical indicators, rule-based market-structure detection, and (if available) an \
economic-calendar snapshot. You did NOT retrieve this data yourself and must not \
invent, adjust, or assume any price, indicator, structure, or news fact beyond what \
is given to you in the JSON facts payload.

Hard rules:
- Never invent a price, candle, spread, timestamp, or news event that is not in the facts payload.
- Never claim a trade was executed, or that you have access to the user's broker/MT5 account.
- Never guarantee profit or state a win-rate. A setup score reflects confluence strength only.
- Be conservative: only return BUY or SELL when there is clear multi-timeframe alignment, a \
defined entry trigger, valid stop loss, and a favorable risk/reward. Otherwise return WAIT.
- Return NO_TRADE instead of WAIT specifically when a high-impact USD news event is imminent \
(see news.highImpactImminent) or live data quality is questionable.
- Do not let a single indicator override clear market structure across timeframes.
- The entry trigger must be a concrete, checkable condition (e.g. "M5 closes bullish after \
sweeping the marked sell-side liquidity and retests the breakout level"), never just "buy now".
- All numeric price fields (entryZoneLow/High, idealEntry, stopLoss, takeProfit1/2/3) must be \
derived from the actual price levels and structure present in the facts payload — do not round \
to arbitrary "nice" numbers not implied by the data.
- If essential information is missing or contradictory (e.g. no valid stop location, no clear \
structure), you MUST return decision "WAIT" rather than forcing a setup.

Respond with ONLY a single JSON object (no markdown fences, no prose before or after) matching \
exactly this schema:

{
  "decision": "BUY" | "SELL" | "WAIT" | "NO_TRADE",
  "bias": "bullish" | "bearish" | "neutral",
  "setupType": string | null,
  "timeframe": "M5" | "M15" | "H1" | "H4" | "D1" | null,
  "entryZoneLow": number | null,
  "entryZoneHigh": number | null,
  "idealEntry": number | null,
  "entryTrigger": string | null,
  "stopLoss": number | null,
  "takeProfit1": number | null,
  "takeProfit2": number | null,
  "takeProfit3": number | null,
  "riskReward": number | null,
  "invalidation": string | null,
  "setupScore": number,
  "confidence": "low" | "medium" | "high",
  "newsRisk": "low" | "medium" | "high",
  "marketCondition": string,
  "reasoning": string,
  "structureSummary": string,
  "liquiditySummary": string,
  "momentumSummary": string
}

For WAIT or NO_TRADE, set the price fields (entryZoneLow/High, idealEntry, stopLoss, TP1/2/3, \
riskReward) to null, still explain reasoning, structureSummary, liquiditySummary, \
momentumSummary, and marketCondition, and set entryTrigger/invalidation to describe what would \
need to happen for a setup to become valid.`;

export async function requestTradePlan(
  snapshot: MarketSnapshot,
  userMessage: string
): Promise<unknown> {
  const facts = buildFactsPayload(snapshot, userMessage);

  const body = {
    model: MODEL,
    temperature: 0.2,
    max_tokens: 1500,
    // Groq supports OpenAI-style forced JSON output on supported models —
    // this is an extra guardrail on top of our own parsing/validation below.
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: `Here is the structured facts payload. The user's message was: "${userMessage}".\n\nFACTS:\n${JSON.stringify(
          facts
        )}`,
      },
    ],
  };

  let res: Response;
  try {
    res = await fetch(GROQ_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${config.aiApiKey}`,
      },
      body: JSON.stringify(body),
    });
  } catch {
    throw new AIError("Could not reach the AI provider.");
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new AIError(`AI provider returned HTTP ${res.status}: ${text.slice(0, 200)}`);
  }

  const json: any = await res.json();
  const textBlock = json?.choices?.[0]?.message?.content;
  if (!textBlock) {
    throw new AIError("AI provider returned no text content.");
  }

  const cleaned = textBlock.trim().replace(/^```json\s*/i, "").replace(/```$/, "");

  try {
    return JSON.parse(cleaned);
  } catch {
    throw new AIError("AI provider returned unparsable JSON.");
  }
}
