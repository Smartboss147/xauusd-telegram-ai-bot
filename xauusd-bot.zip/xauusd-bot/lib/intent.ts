export type Intent =
  | "start"
  | "help"
  | "status"
  | "analyze"
  | "bias"
  | "structure"
  | "news"
  | "risk"
  | "unknown";

const ANALYZE_KEYWORDS = [
  "analyze",
  "analyse",
  "gold",
  "xauusd",
  "xau/usd",
  "setup",
  "trade plan",
  "buy or sell",
  "should i buy",
  "should i sell",
  "should i wait",
  "high-quality",
  "high quality",
];

export function detectIntent(text: string): Intent {
  const t = text.trim().toLowerCase();

  if (t === "/start" || t === "start") return "start";
  if (t.startsWith("/help") || t === "help") return "help";
  if (t.startsWith("/status")) return "status";
  if (t.startsWith("/risk")) return "risk";
  if (t.startsWith("/news")) return "news";
  if (t.startsWith("/structure")) return "structure";
  if (t.startsWith("/bias")) return "bias";
  if (t.startsWith("/analyze") || t.startsWith("/gold") || t.startsWith("/xauusd")) {
    return "analyze";
  }

  if (/risk/.test(t) && /(balance|\$|%)/.test(t)) return "risk";
  if (/\bbias\b/.test(t)) return "bias";
  if (/\bstructure\b/.test(t)) return "structure";
  if (/\bnews\b/.test(t)) return "news";

  if (ANALYZE_KEYWORDS.some((kw) => t.includes(kw))) return "analyze";

  return "unknown";
}

export interface ParsedRiskArgs {
  balance: number;
  riskPercent: number;
  entry: number;
  stopLoss: number;
}

/**
 * Accepts either a slash-command form:
 *   /risk 500 1 2650 2645
 * or a natural-language form:
 *   "My balance is $500 and I want to risk 1%, entry 2650 stop 2645"
 * Returns null if it can't confidently extract all four numbers.
 */
export function parseRiskArgs(text: string): ParsedRiskArgs | null {
  const numbers = (text.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);

  const slashMatch = text.trim().match(/^\/risk\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)/i);
  if (slashMatch) {
    const [, balance, riskPercent, entry, stopLoss] = slashMatch.map(Number);
    return { balance, riskPercent, entry, stopLoss };
  }

  const balanceMatch = text.match(/balance[^\d]{0,5}(\d+(?:\.\d+)?)/i);
  const riskMatch = text.match(/risk[^\d]{0,5}(\d+(?:\.\d+)?)\s*%/i);
  const entryMatch = text.match(/entry[^\d]{0,5}(\d+(?:\.\d+)?)/i);
  const stopMatch = text.match(/stop[^\d]{0,5}(\d+(?:\.\d+)?)/i);

  if (balanceMatch && riskMatch && entryMatch && stopMatch) {
    return {
      balance: Number(balanceMatch[1]),
      riskPercent: Number(riskMatch[1]),
      entry: Number(entryMatch[1]),
      stopLoss: Number(stopMatch[1]),
    };
  }

  if (numbers.length >= 4) {
    const [balance, riskPercent, entry, stopLoss] = numbers;
    return { balance, riskPercent, entry, stopLoss };
  }

  return null;
}
