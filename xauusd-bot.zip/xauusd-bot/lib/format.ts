import { LiveQuote, MarketSnapshot, RiskCalcResult, TradePlan } from "./types";

const DIVIDER = "━━━━━━━━━━━━━━━━━━━━";

const DECISION_EMOJI: Record<TradePlan["decision"], string> = {
  BUY: "🟢 BUY",
  SELL: "🔴 SELL",
  WAIT: "🟡 WAIT",
  NO_TRADE: "⚪ NO TRADE",
};

function fmtPrice(v: number | null): string {
  return v === null ? "—" : v.toFixed(2);
}

export function formatTradePlan(plan: TradePlan, quote: LiveQuote, snapshot: MarketSnapshot): string {
  const lines: string[] = [];
  lines.push(DIVIDER);
  lines.push("🥇 XAUUSD AI ANALYSIS");
  lines.push(DIVIDER, "");
  lines.push(`📊 MARKET: XAUUSD`);
  lines.push(`💰 PRICE: ${fmtPrice(quote.price)}  (${quote.provider}, ${quote.ageSeconds}s old)`);
  lines.push(`🕒 SESSION: ${snapshot.session.label}`);
  lines.push(`📈 BIAS: ${plan.bias.toUpperCase()}`);
  if (plan.timeframe) lines.push(`⏱ TIMEFRAME: ${plan.timeframe}`);
  if (plan.setupType) lines.push(`🔥 SETUP: ${plan.setupType}`);
  lines.push("");
  lines.push(`🎯 DECISION: ${DECISION_EMOJI[plan.decision]}`);
  lines.push("");

  if (plan.decision === "BUY" || plan.decision === "SELL") {
    lines.push(`📍 ENTRY ZONE: ${fmtPrice(plan.entryZoneLow)} – ${fmtPrice(plan.entryZoneHigh)}`);
    lines.push(`🎯 IDEAL ENTRY: ${fmtPrice(plan.idealEntry)}`);
    lines.push(`🛑 STOP LOSS: ${fmtPrice(plan.stopLoss)}`);
    lines.push(`🎯 TP1: ${fmtPrice(plan.takeProfit1)}`);
    if (plan.takeProfit2 !== null) lines.push(`🎯 TP2: ${fmtPrice(plan.takeProfit2)}`);
    if (plan.takeProfit3 !== null) lines.push(`🎯 TP3: ${fmtPrice(plan.takeProfit3)}`);
    lines.push(`📐 RISK/REWARD: ${plan.riskReward ? "1:" + plan.riskReward.toFixed(1) : "—"}`);
  }

  lines.push(`⭐ SETUP SCORE: ${plan.setupScore}/100`);
  lines.push(`🧠 CONFIDENCE: ${plan.confidence.toUpperCase()}`);
  lines.push(`⚠️ NEWS RISK: ${plan.newsRisk.toUpperCase()}`);
  lines.push("");

  if (plan.entryTrigger) {
    lines.push(`🔑 ENTRY TRIGGER:`);
    lines.push(plan.entryTrigger);
    lines.push("");
  }
  if (plan.invalidation) {
    lines.push(`❌ INVALIDATION:`);
    lines.push(plan.invalidation);
    lines.push("");
  }

  lines.push(`📖 MARKET CONDITION: ${plan.marketCondition}`);
  lines.push(`🧱 STRUCTURE: ${plan.structureSummary}`);
  lines.push(`💧 LIQUIDITY: ${plan.liquiditySummary}`);
  lines.push(`⚡ MOMENTUM: ${plan.momentumSummary}`);
  lines.push("");
  lines.push(`🧠 REASONING:`);
  lines.push(plan.reasoning);
  lines.push("");

  if (!snapshot.news.available) {
    lines.push(`ℹ️ News-risk check: unavailable (${snapshot.news.reason})`);
    lines.push("");
  } else if (snapshot.news.events.length > 0) {
    lines.push(`📰 UPCOMING WATCHED EVENTS:`);
    for (const e of snapshot.news.events.slice(0, 3)) {
      lines.push(`• ${e.title} — in ${Math.max(0, e.minutesUntil)} min (${e.impact})`);
    }
    lines.push("");
  }

  lines.push(DIVIDER);
  lines.push("⚠️ MANUAL EXECUTION");
  lines.push(DIVIDER);
  lines.push("This is an AI-generated market analysis. No MT5 trade has been executed.");
  lines.push("Open Exness MT5 manually if you decide to trade.");
  lines.push(DIVIDER);

  return lines.join("\n");
}

export function formatStaleDataMessage(ageSeconds: number): string {
  return [
    "🔴 MARKET DATA STALE",
    "",
    `The latest XAUUSD price is ${ageSeconds}s old, which exceeds the freshness threshold.`,
    "I cannot safely generate a fresh XAUUSD setup until live market data is available.",
    "Try again in a moment.",
  ].join("\n");
}

export function formatDataUnavailableMessage(detail: string): string {
  return [
    "Live XAUUSD market data is currently unavailable, so I cannot safely generate a live trade setup.",
    "",
    `Detail: ${detail}`,
  ].join("\n");
}

export function formatValidationFailureMessage(): string {
  return "Analysis could not be validated safely. Please try again.";
}

export function formatRiskCalc(result: RiskCalcResult, balance: number, riskPercent: number): string {
  const lines = [
    "📐 RISK CALCULATOR",
    "",
    `Balance: $${balance.toFixed(2)}`,
    `Risk: ${riskPercent}%`,
    `Max risk amount: $${result.maxRiskAmount.toFixed(2)}`,
    `Stop distance: ${result.stopLossDistancePips.toFixed(2)}`,
  ];
  if (result.suggestedLotSize !== null) {
    lines.push(`Estimated lot size: ${result.suggestedLotSize}`);
  }
  lines.push("", result.note);
  return lines.join("\n");
}

export function formatStatus(checks: {
  telegram: boolean;
  ai: boolean;
  marketData: boolean;
  news: boolean;
}): string {
  const flag = (b: boolean) => (b ? "🟢" : "🔴");
  return [
    "🤖 GOLD AI TRADING BOT",
    "",
    `Telegram: ${flag(checks.telegram)} ${checks.telegram ? "CONNECTED" : "ERROR"}`,
    `AI: ${flag(checks.ai)} ${checks.ai ? "READY" : "NOT CONFIGURED"}`,
    `Market Data: ${flag(checks.marketData)} ${checks.marketData ? "LIVE" : "UNAVAILABLE"}`,
    `XAUUSD: ${flag(checks.marketData)} ${checks.marketData ? "AVAILABLE" : "UNAVAILABLE"}`,
    `News: ${checks.news ? "🟢 AVAILABLE" : "⚪ NOT CONFIGURED"}`,
    "Vercel: 🟢 ONLINE",
    "",
    "Exness MT5: ⚪ NOT CONNECTED",
    "Execution: 🔴 DISABLED",
    "Mode: 📱 IPHONE MANUAL TRADING",
    "",
    "Database: ⚪ NONE",
    "Memory: ⚪ DISABLED",
  ].join("\n");
}

export function formatHelp(): string {
  return [
    "🥇 XAUUSD AI Trading Assistant",
    "",
    "Just tell me what you want in plain English, e.g.:",
    '• "Analyze XAUUSD"',
    '• "Give me a gold trade setup"',
    '• "Should I buy or sell gold?"',
    '• "What\'s the gold bias right now?"',
    '• "Risk $500 balance, 1% risk, entry 2650, stop 2645"',
    "",
    "Commands:",
    "/analyze /gold /xauusd — full multi-timeframe analysis",
    "/bias — quick directional bias only",
    "/structure — market structure summary",
    "/news — upcoming high-impact USD events",
    "/risk <balance> <risk%> <entry> <stop> — position size calculator",
    "/status — system health",
    "/help — this message",
    "",
    "Every analysis uses live market data. If live data isn't fresh or available, I will tell you " +
      "instead of guessing. All trades are executed manually by you in Exness MT5 — this bot never " +
      "places trades.",
  ].join("\n");
}

export function formatUnauthorized(): string {
  return "Unauthorized user.";
}
