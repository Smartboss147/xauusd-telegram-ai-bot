import { config } from "./config";

/**
 * Stateless authorization: compares the incoming Telegram user id against
 * an allow-list read from an environment variable. Nothing is written to
 * disk or a database — there is no concept of "known users", only "is this
 * id in the env var right now".
 */
export function isAuthorized(userId: number | undefined): boolean {
  const allowed = config.allowedUserIds;
  if (!allowed || allowed.length === 0) {
    // No allow-list configured: bot is open to anyone who has the link.
    // This is intentionally permitted (documented as a risk in .env.example)
    // rather than silently blocking everyone on a misconfiguration.
    return true;
  }
  if (!userId) return false;
  return allowed.includes(userId);
}
