import { config } from "./config";
import { Candle, LiveQuote, Timeframe } from "./types";

const BASE = "https://api.twelvedata.com";
const SYMBOL = "XAU/USD";

// Twelve Data interval strings per our internal Timeframe labels.
const INTERVAL_MAP: Record<Timeframe, string> = {
  M1: "1min",
  M5: "5min",
  M15: "15min",
  M30: "30min",
  H1: "1h",
  H4: "4h",
  D1: "1day",
};

// How stale a live quote is allowed to be before we refuse to trade on it.
// Gold is a 24/5 OTC-style market; a healthy feed updates every few seconds
// while the session is open, so a wide-but-safe threshold catches genuinely
// frozen/broken feeds without false-flagging normal network latency.
const MAX_QUOTE_AGE_SECONDS = 120;

class MarketDataError extends Error {}

async function td<T>(path: string, params: Record<string, string>): Promise<T> {
  const url = new URL(`${BASE}/${path}`);
  url.searchParams.set("apikey", config.marketDataApiKey);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);

  let res: Response;
  try {
    res = await fetch(url.toString(), { method: "GET" });
  } catch (e) {
    throw new MarketDataError("Network error contacting market data provider.");
  }

  const json: any = await res.json().catch(() => null);
  if (!res.ok || !json) {
    throw new MarketDataError(`Market data provider returned an error (HTTP ${res.status}).`);
  }
  if (json.status === "error" || json.code >= 400) {
    throw new MarketDataError(json.message || "Market data provider returned an error.");
  }
  return json as T;
}

export async function getLiveQuote(): Promise<LiveQuote> {
  const data = await td<any>("quote", { symbol: SYMBOL });

  const price = Number(data.close ?? data.price);
  if (!Number.isFinite(price) || price <= 0) {
    throw new MarketDataError("Provider returned an invalid price.");
  }

  const bid = data.bid != null ? Number(data.bid) : null;
  const ask = data.ask != null ? Number(data.ask) : null;

  // Twelve Data returns a unix timestamp for the quote in `timestamp`.
  const tsSeconds = Number(data.timestamp);
  const ageSeconds = Number.isFinite(tsSeconds)
    ? Math.max(0, Math.floor(Date.now() / 1000) - tsSeconds)
    : Number.POSITIVE_INFINITY; // no timestamp at all => treat as stale

  const marketOpen = typeof data.is_market_open === "boolean" ? data.is_market_open : null;

  return {
    symbol: "XAUUSD",
    price,
    bid,
    ask,
    spread: bid != null && ask != null ? Number((ask - bid).toFixed(2)) : null,
    timestampUtc: Number.isFinite(tsSeconds)
      ? new Date(tsSeconds * 1000).toISOString()
      : new Date().toISOString(),
    ageSeconds,
    provider: "Twelve Data",
    marketOpen,
  };
}

export function isQuoteStale(quote: LiveQuote): boolean {
  return quote.ageSeconds > MAX_QUOTE_AGE_SECONDS;
}

export async function getCandles(timeframe: Timeframe, outputSize = 120): Promise<Candle[]> {
  const interval = INTERVAL_MAP[timeframe];
  const data = await td<any>("time_series", {
    symbol: SYMBOL,
    interval,
    outputsize: String(outputSize),
  });

  const values = data.values;
  if (!Array.isArray(values) || values.length === 0) {
    throw new MarketDataError(`No candle data available for ${timeframe}.`);
  }

  // Twelve Data returns newest-first; we want oldest-first for analysis.
  const candles: Candle[] = values
    .map((v: any) => ({
      time: Math.floor(new Date(v.datetime.replace(" ", "T") + "Z").getTime() / 1000),
      open: Number(v.open),
      high: Number(v.high),
      low: Number(v.low),
      close: Number(v.close),
    }))
    .filter(
      (c: Candle) =>
        Number.isFinite(c.open) &&
        Number.isFinite(c.high) &&
        Number.isFinite(c.low) &&
        Number.isFinite(c.close)
    )
    .reverse();

  if (candles.length === 0) {
    throw new MarketDataError(`Candle data for ${timeframe} was malformed.`);
  }
  return candles;
}

export { MarketDataError };
