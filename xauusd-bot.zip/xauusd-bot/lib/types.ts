// Shared types. Kept in one place so the "shape of a trade plan" is defined
// once and enforced everywhere (fetch -> analyze -> AI -> validate -> format).

export type Timeframe = "M1" | "M5" | "M15" | "M30" | "H1" | "H4" | "D1";

export interface Candle {
  time: number; // unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface IndicatorSnapshot {
  ema20: number | null;
  ema50: number | null;
  ema200: number | null;
  rsi14: number | null;
  atr14: number | null;
  macd: { macd: number; signal: number; histogram: number } | null;
}

export interface SwingPoint {
  time: number;
  price: number;
  type: "high" | "low";
}

export interface StructureSnapshot {
  timeframe: Timeframe;
  trend: "bullish" | "bearish" | "ranging";
  lastBOS: "bullish" | "bearish" | null;
  lastCHOCH: "bullish" | "bearish" | null;
  swingHigh: number | null;
  swingLow: number | null;
  equalHighs: boolean;
  equalLows: boolean;
  candles: number; // how many candles this was computed from
}

export interface TimeframeAnalysis {
  timeframe: Timeframe;
  candles: Candle[];
  indicators: IndicatorSnapshot;
  structure: StructureSnapshot;
}

export interface LiveQuote {
  symbol: string;
  price: number;
  bid: number | null;
  ask: number | null;
  spread: number | null;
  timestampUtc: string;
  ageSeconds: number;
  provider: string;
  marketOpen: boolean | null;
}

export interface NewsEvent {
  title: string;
  country: string;
  impact: "low" | "medium" | "high";
  timeUtc: string;
  minutesUntil: number;
}

export interface NewsSnapshot {
  available: boolean;
  events: NewsEvent[];
  highImpactImminent: boolean;
  reason?: string; // set when available=false
}

export interface MarketSnapshot {
  quote: LiveQuote;
  timeframes: Partial<Record<Timeframe, TimeframeAnalysis>>;
  news: NewsSnapshot;
  session: {
    london: boolean;
    newYork: boolean;
    overlap: boolean;
    label: string;
  };
}

export type Decision = "BUY" | "SELL" | "WAIT" | "NO_TRADE";

export interface TradePlan {
  decision: Decision;
  bias: "bullish" | "bearish" | "neutral";
  setupType: string | null;
  timeframe: Timeframe | null;
  entryZoneLow: number | null;
  entryZoneHigh: number | null;
  idealEntry: number | null;
  entryTrigger: string | null;
  stopLoss: number | null;
  takeProfit1: number | null;
  takeProfit2: number | null;
  takeProfit3: number | null;
  riskReward: number | null;
  invalidation: string | null;
  setupScore: number; // 0-100
  confidence: "low" | "medium" | "high";
  newsRisk: "low" | "medium" | "high";
  marketCondition: string;
  reasoning: string;
  structureSummary: string;
  liquiditySummary: string;
  momentumSummary: string;
}

export interface RiskCalcInput {
  balance: number;
  riskPercent: number;
  entry: number;
  stopLoss: number;
}

export interface RiskCalcResult {
  maxRiskAmount: number;
  stopLossDistancePips: number;
  suggestedLotSize: number | null;
  note: string;
}
