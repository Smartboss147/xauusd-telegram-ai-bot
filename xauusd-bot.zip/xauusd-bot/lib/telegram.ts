import { config } from "./config";

const API_BASE = "https://api.telegram.org";

export interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    date: number;
    chat: { id: number; type: string };
    from?: { id: number; username?: string; first_name?: string };
    text?: string;
  };
}

/**
 * Sends a message back to a chat. Telegram messages are capped at 4096
 * characters — we defensively split long analyses into multiple messages
 * rather than truncating (which could cut off a stop loss / invalidation
 * and mislead the user).
 */
export async function sendMessage(chatId: number, text: string): Promise<void> {
  const chunks = splitMessage(text, 4000);
  for (const chunk of chunks) {
    const res = await fetch(`${API_BASE}/bot${config.telegramBotToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: chunk,
        disable_web_page_preview: true,
      }),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      // Never throw the raw body upstream — it could theoretically contain
      // the bot token in an error echo on some proxies. Log a trimmed form.
      console.error("Telegram sendMessage failed", res.status, body.slice(0, 300));
    }
  }
}

function splitMessage(text: string, maxLen: number): string[] {
  if (text.length <= maxLen) return [text];
  const parts: string[] = [];
  let remaining = text;
  while (remaining.length > maxLen) {
    let cut = remaining.lastIndexOf("\n", maxLen);
    if (cut <= 0) cut = maxLen;
    parts.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut);
  }
  if (remaining.length) parts.push(remaining);
  return parts;
}

/**
 * Verifies the `X-Telegram-Bot-Api-Secret-Token` header Telegram sends on
 * every webhook request when a secret_token was registered with
 * setWebhook. This is the officially supported way to authenticate that a
 * request genuinely came from Telegram (see Telegram Bot API docs for
 * setWebhook). If no secret is configured, verification is skipped (still
 * functional, just less hardened) so first-time setup isn't blocked.
 */
export function verifyTelegramSecret(headerValue: string | string[] | undefined): boolean {
  if (!config.telegramWebhookSecret) return true;
  const value = Array.isArray(headerValue) ? headerValue[0] : headerValue;
  return value === config.telegramWebhookSecret;
}

export async function registerWebhook(url: string): Promise<unknown> {
  const params: Record<string, string> = { url };
  if (config.telegramWebhookSecret) params.secret_token = config.telegramWebhookSecret;
  const res = await fetch(`${API_BASE}/bot${config.telegramBotToken}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });
  return res.json();
}
