import { config } from "./config";
import { NewsEvent, NewsSnapshot } from "./types";

// High-impact USD releases that matter most for gold. Anything else on the
// calendar is ignored for the "should I be cautious" signal even if the
// provider tags it high-impact for another currency.
const WATCHED_KEYWORDS = [
  "cpi",
  "pce",
  "nonfarm",
  "non-farm",
  "nfp",
  "fomc",
  "fed ",
  "federal funds",
  "interest rate",
  "unemployment",
  "gdp",
  "powell",
  "ppi",
];

const LOOKAHEAD_MINUTES = 180; // flag events within the next 3 hours

export async function getNewsSnapshot(): Promise<NewsSnapshot> {
  if (!config.newsApiKey) {
    return {
      available: false,
      events: [],
      highImpactImminent: false,
      reason: "No NEWS_API_KEY configured — news-risk checking is disabled.",
    };
  }

  const now = new Date();
  const from = now.toISOString().slice(0, 10);
  const to = new Date(now.getTime() + 2 * 24 * 3600 * 1000).toISOString().slice(0, 10);

  const url = new URL("https://finnhub.io/api/v1/calendar/economic");
  url.searchParams.set("from", from);
  url.searchParams.set("to", to);
  url.searchParams.set("token", config.newsApiKey);

  let res: Response;
  try {
    res = await fetch(url.toString());
  } catch {
    return {
      available: false,
      events: [],
      highImpactImminent: false,
      reason: "Could not reach the news/economic-calendar provider.",
    };
  }

  if (!res.ok) {
    return {
      available: false,
      events: [],
      highImpactImminent: false,
      reason: `News provider returned HTTP ${res.status}.`,
    };
  }

  const json: any = await res.json().catch(() => null);
  const raw = json?.economicCalendar ?? [];
  if (!Array.isArray(raw)) {
    return {
      available: false,
      events: [],
      highImpactImminent: false,
      reason: "News provider returned an unexpected format.",
    };
  }

  const events: NewsEvent[] = raw
    .filter((e: any) => e.country === "US")
    .filter((e: any) =>
      WATCHED_KEYWORDS.some((kw) => String(e.event || "").toLowerCase().includes(kw))
    )
    .map((e: any) => {
      const t = new Date(e.time ?? `${e.date}T00:00:00Z`);
      const minutesUntil = Math.round((t.getTime() - now.getTime()) / 60000);
      const impact: NewsEvent["impact"] =
        e.impact === "3" || e.impact === 3 || e.impact === "high" ? "high" : "medium";
      return {
        title: String(e.event || "US economic release"),
        country: "US",
        impact,
        timeUtc: t.toISOString(),
        minutesUntil,
      };
    })
    .filter((e: NewsEvent) => e.minutesUntil > -30 && e.minutesUntil < 24 * 60)
    .sort((a: NewsEvent, b: NewsEvent) => a.minutesUntil - b.minutesUntil);

  const highImpactImminent = events.some(
    (e) => e.impact === "high" && e.minutesUntil >= 0 && e.minutesUntil <= LOOKAHEAD_MINUTES
  );

  return { available: true, events: events.slice(0, 8), highImpactImminent };
}
