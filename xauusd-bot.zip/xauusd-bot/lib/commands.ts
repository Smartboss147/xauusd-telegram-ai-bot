import { buildMarketSnapshot, MarketDataError, StaleDataError, SnapshotError } from "./snapshot";
import { requestTradePlan, AIError } from "./ai";
import { validateTradePlan, ValidationError } from "./validate";
import { calculateRisk } from "./risk";
import { parseRiskArgs } from "./intent";
import {
  formatDataUnavailableMessage,
  formatHelp,
  formatRiskCalc,
  formatStaleDataMessage,
  formatStatus,
  formatTradePlan,
  formatValidationFailureMessage,
} from "./format";
import { config } from "./config";
import { getNewsSnapshot } from "./news";
import { getLiveQuote } from "./marketData";

/**
 * Runs the full pipeline: live data -> indicators/structure -> AI reasoning
 * -> strict validation -> Telegram-formatted text. Used for /analyze, /gold,
 * /xauusd, /bias, /structure, and general natural-language analysis
 * requests. Every branch that can fail returns a clear, honest message
 * instead of throwing something generic upstream.
 */
export async function runAnalysis(userMessage: string): Promise<string> {
  let snapshot;
  try {
    snapshot = await buildMarketSnapshot();
  } catch (e) {
    if (e instanceof StaleDataError) {
      return formatStaleDataMessage(Number(e.message.match(/(\d+)s/)?.[1] ?? "0"));
    }
    if (e instanceof MarketDataError || e instanceof SnapshotError) {
      return formatDataUnavailableMessage(e.message);
    }
    console.error("Unexpected snapshot error", e);
    return formatDataUnavailableMessage("Unexpected error while fetching market data.");
  }

  if (snapshot.news.highImpactImminent) {
    // We still let the AI decide (it may still say WAIT/NO_TRADE with reasoning),
    // but the facts payload already carries this so the AI is expected to be
    // extra conservative — see the system prompt in lib/ai.ts.
  }

  let rawPlan: unknown;
  try {
    rawPlan = await requestTradePlan(snapshot, userMessage);
  } catch (e) {
    if (e instanceof AIError) {
      return `AI analysis is temporarily unavailable: ${e.message}`;
    }
    console.error("Unexpected AI error", e);
    return "AI analysis is temporarily unavailable. Please try again.";
  }

  try {
    const plan = validateTradePlan(rawPlan, snapshot.quote);
    return formatTradePlan(plan, snapshot.quote, snapshot);
  } catch (e) {
    if (e instanceof ValidationError) {
      console.error("Validation rejected AI output:", e.message, rawPlan);
    }
    return formatValidationFailureMessage();
  }
}

export async function runNewsCheck(): Promise<string> {
  const news = await getNewsSnapshot();
  if (!news.available) {
    return `ℹ️ News-risk check is unavailable.\n${news.reason ?? ""}`;
  }
  if (news.events.length === 0) {
    return "📰 No watched high-impact USD events in the next 24 hours.";
  }
  const lines = ["📰 UPCOMING WATCHED USD EVENTS", ""];
  for (const e of news.events) {
    lines.push(`• ${e.title} — in ${Math.max(0, e.minutesUntil)} min (impact: ${e.impact})`);
  }
  if (news.highImpactImminent) {
    lines.push("", "🚫 A high-impact event is imminent — expect elevated volatility risk.");
  }
  return lines.join("\n");
}

export function runRiskCalc(text: string): string {
  const args = parseRiskArgs(text);
  if (!args) {
    return [
      "I need four numbers to calculate risk: balance, risk %, entry price, stop-loss price.",
      "",
      "Example: /risk 500 1 2650 2645",
      'Or: "My balance is $500, risk 1%, entry 2650, stop 2645"',
    ].join("\n");
  }
  if (args.balance <= 0 || args.riskPercent <= 0 || args.entry <= 0 || args.stopLoss <= 0) {
    return "All values must be positive numbers.";
  }
  const result = calculateRisk(args);
  return formatRiskCalc(result, args.balance, args.riskPercent);
}

export async function runStatus(): Promise<string> {
  let marketDataOk = true;
  try {
    await getLiveQuote();
  } catch {
    marketDataOk = false;
  }

  let aiOk = true;
  try {
    config.aiApiKey;
  } catch {
    aiOk = false;
  }

  const newsOk = Boolean(config.newsApiKey);

  return formatStatus({
    telegram: true, // if this code is running, the webhook call itself succeeded
    ai: aiOk,
    marketData: marketDataOk,
    news: newsOk,
  });
}

export function runHelp(): string {
  return formatHelp();
}

export function runStart(): string {
  return [
    "👋 Welcome to your XAUUSD AI Trading Assistant.",
    "",
    "This bot analyzes live gold market data and gives you a structured, conservative trade " +
      "plan. It never trades for you — you execute manually in Exness MT5.",
    "",
    formatHelp(),
  ].join("\n");
}
