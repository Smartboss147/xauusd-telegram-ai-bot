import { Decision, LiveQuote, TradePlan } from "./types";

export class ValidationError extends Error {}

const DECISIONS: Decision[] = ["BUY", "SELL", "WAIT", "NO_TRADE"];
const BIASES = ["bullish", "bearish", "neutral"];
const LEVELS = ["low", "medium", "high"];

function isFiniteNumberOrNull(v: unknown): v is number | null {
  return v === null || (typeof v === "number" && Number.isFinite(v));
}

/**
 * Rejects anything that doesn't match the schema, plus a few sanity checks
 * against the live quote so an AI-hallucinated price can never reach the
 * user framed as real. This is intentionally strict — a rejection here
 * degrades to a safe "could not validate" message rather than ever
 * forwarding unchecked AI output.
 */
export function validateTradePlan(raw: unknown, quote: LiveQuote): TradePlan {
  if (typeof raw !== "object" || raw === null) {
    throw new ValidationError("AI response was not a JSON object.");
  }
  const r = raw as Record<string, unknown>;

  if (!DECISIONS.includes(r.decision as Decision)) {
    throw new ValidationError("Missing or invalid 'decision' field.");
  }
  if (!BIASES.includes(r.bias as string)) {
    throw new ValidationError("Missing or invalid 'bias' field.");
  }
  if (!LEVELS.includes(r.confidence as string)) {
    throw new ValidationError("Missing or invalid 'confidence' field.");
  }
  if (!LEVELS.includes(r.newsRisk as string)) {
    throw new ValidationError("Missing or invalid 'newsRisk' field.");
  }
  if (typeof r.setupScore !== "number" || r.setupScore < 0 || r.setupScore > 100) {
    throw new ValidationError("Missing or invalid 'setupScore' field.");
  }

  const numericFields = [
    "entryZoneLow",
    "entryZoneHigh",
    "idealEntry",
    "stopLoss",
    "takeProfit1",
    "takeProfit2",
    "takeProfit3",
    "riskReward",
  ];
  for (const f of numericFields) {
    if (!isFiniteNumberOrNull(r[f])) {
      throw new ValidationError(`Field '${f}' must be a number or null.`);
    }
  }

  const decision = r.decision as Decision;

  if (decision === "BUY" || decision === "SELL") {
    // A tradable decision must have a complete, internally-consistent plan.
    const required = ["stopLoss", "idealEntry", "takeProfit1", "entryTrigger", "invalidation"];
    for (const f of required) {
      if (r[f] === null || r[f] === undefined || r[f] === "") {
        throw new ValidationError(`Decision is ${decision} but '${f}' is missing.`);
      }
    }

    const entry = r.idealEntry as number;
    const sl = r.stopLoss as number;
    const tp1 = r.takeProfit1 as number;

    // Sanity-check price levels aren't wildly detached from the live quote —
    // catches hallucinated prices (e.g. wrong order of magnitude).
    const maxDeviation = quote.price * 0.05; // 5% band around live price
    for (const [name, val] of [
      ["idealEntry", entry],
      ["stopLoss", sl],
      ["takeProfit1", tp1],
    ] as const) {
      if (Math.abs(val - quote.price) > maxDeviation) {
        throw new ValidationError(
          `Field '${name}' (${val}) is implausibly far from the live price (${quote.price}).`
        );
      }
    }

    // Directional sanity: for BUY, stop must be below entry and TP1 above;
    // for SELL, the reverse. Catches an internally-inconsistent plan.
    if (decision === "BUY" && !(sl < entry && tp1 > entry)) {
      throw new ValidationError("BUY plan has an inconsistent stop loss / take profit ordering.");
    }
    if (decision === "SELL" && !(sl > entry && tp1 < entry)) {
      throw new ValidationError("SELL plan has an inconsistent stop loss / take profit ordering.");
    }

    if (r.riskReward !== null && (r.riskReward as number) < 0.5) {
      throw new ValidationError("Risk/reward is implausibly poor for a recommended trade.");
    }
  }

  return {
    decision,
    bias: r.bias as TradePlan["bias"],
    setupType: (r.setupType as string) ?? null,
    timeframe: (r.timeframe as TradePlan["timeframe"]) ?? null,
    entryZoneLow: (r.entryZoneLow as number) ?? null,
    entryZoneHigh: (r.entryZoneHigh as number) ?? null,
    idealEntry: (r.idealEntry as number) ?? null,
    entryTrigger: (r.entryTrigger as string) ?? null,
    stopLoss: (r.stopLoss as number) ?? null,
    takeProfit1: (r.takeProfit1 as number) ?? null,
    takeProfit2: (r.takeProfit2 as number) ?? null,
    takeProfit3: (r.takeProfit3 as number) ?? null,
    riskReward: (r.riskReward as number) ?? null,
    invalidation: (r.invalidation as string) ?? null,
    setupScore: r.setupScore as number,
    confidence: r.confidence as TradePlan["confidence"],
    newsRisk: r.newsRisk as TradePlan["newsRisk"],
    marketCondition: String(r.marketCondition ?? ""),
    reasoning: String(r.reasoning ?? ""),
    structureSummary: String(r.structureSummary ?? ""),
    liquiditySummary: String(r.liquiditySummary ?? ""),
    momentumSummary: String(r.momentumSummary ?? ""),
  };
}
