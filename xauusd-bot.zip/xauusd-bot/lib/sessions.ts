// Approximate session windows in UTC (ignores DST shifts for simplicity —
// good enough for a "which session is this" label, not used for anything
// safety-critical).
export function getSession(now = new Date()) {
  const h = now.getUTCHours();
  const london = h >= 7 && h < 16;
  const newYork = h >= 12 && h < 21;
  const overlap = london && newYork;

  let label = "Asian / low liquidity";
  if (overlap) label = "London/New York overlap (highest liquidity)";
  else if (london) label = "London session";
  else if (newYork) label = "New York session";

  return { london, newYork, overlap, label };
}
