// Central place that reads process.env. Nothing here is persisted anywhere —
// it's read fresh on every cold start / invocation, which is exactly what we
// want for a stateless Vercel function.

function required(name: string): string {
  const v = process.env[name];
  if (!v) {
    throw new MissingEnvError(name);
  }
  return v;
}

export class MissingEnvError extends Error {
  constructor(public varName: string) {
    super(`Missing required environment variable: ${varName}`);
    this.name = "MissingEnvError";
  }
}

export const config = {
  get telegramBotToken() {
    return required("TELEGRAM_BOT_TOKEN");
  },
  get telegramWebhookSecret() {
    return process.env.TELEGRAM_WEBHOOK_SECRET || null;
  },
  get allowedUserIds(): number[] | null {
    const raw = process.env.TELEGRAM_ALLOWED_USER_ID;
    if (!raw) return null;
    return raw
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .map((s) => Number(s));
  },
  get aiApiKey() {
    return required("AI_API_KEY");
  },
  get marketDataApiKey() {
    return required("MARKET_DATA_API_KEY");
  },
  get newsApiKey() {
    return process.env.NEWS_API_KEY || null;
  },
};
