# XAUUSD AI Trading Assistant — Telegram + Vercel (Stateless)

A personal, serverless Telegram bot that analyzes live XAUUSD (gold) data and
returns a structured, conservative trade plan. You execute every trade
manually in Exness MT5 on your iPhone — this bot never places, modifies, or
confirms any trade.

No database. No persistent memory. No Railway, VPS, or desktop dependency.

---

## A. Architecture

```
iPhone (Telegram app)
      │  "Analyze XAUUSD"
      ▼
Telegram Bot API
      │  webhook POST
      ▼
Vercel Serverless Function  ──►  api/telegram/webhook.ts
      │
      ├─► lib/auth.ts            (env-var allow-list check, no user DB)
      ├─► lib/intent.ts          (command / natural-language routing)
      │
      ├─► lib/snapshot.ts        orchestrates:
      │     ├─ lib/marketData.ts   → Twelve Data: live quote + OHLC candles
      │     ├─ lib/indicators.ts   → EMA/RSI/MACD/ATR computed locally
      │     ├─ lib/structure.ts    → swing highs/lows, BOS/CHOCH, liquidity
      │     ├─ lib/news.ts         → Finnhub economic calendar (optional)
      │     └─ lib/sessions.ts     → London/NY session label
      │
      ├─► lib/ai.ts              (Groq LLM receives ONLY the structured facts
      │                            above — never invents data — returns JSON)
      ├─► lib/validate.ts        (rejects malformed/hallucinated/inverted
      │                            AI output before it ever reaches you)
      ├─► lib/format.ts          (renders the Telegram message)
      └─► lib/telegram.ts        (sends the reply)

Every invocation is independent. Nothing is written to disk, a database, or
any cache between requests. Cold start or warm start, the next message
always triggers a completely fresh fetch → analyze → reason → validate cycle.
```

The only in-memory state anywhere in the codebase is a small `Set` of recently
seen Telegram `update_id`s in `api/telegram/webhook.ts`, used purely to avoid
double-replying if Telegram retries a delivery. It lives only in a warm
Lambda instance's memory, is never written anywhere, and can be wiped at any
moment (cold start / redeploy / scale event) with zero consequence — it is
not "memory" about you, just delivery-retry hygiene.

---

## B. Project Structure

```
xauusd-bot/
├── api/
│   ├── telegram/
│   │   └── webhook.ts      # Telegram webhook entrypoint (Vercel function)
│   └── status.ts           # minimal public health-check endpoint
├── lib/
│   ├── config.ts           # reads env vars, throws a typed error if missing
│   ├── types.ts            # shared TypeScript types (single source of truth)
│   ├── telegram.ts         # sendMessage, webhook secret verification
│   ├── auth.ts             # allow-list authorization (no DB)
│   ├── intent.ts           # command + natural-language intent detection
│   ├── marketData.ts       # Twelve Data client (quote + candles)
│   ├── indicators.ts       # EMA / RSI / MACD / ATR (computed locally)
│   ├── structure.ts        # swing detection, BOS/CHOCH, equal highs/lows
│   ├── sessions.ts         # London / New York session detection
│   ├── news.ts             # Finnhub economic calendar (optional)
│   ├── risk.ts             # position-size / risk calculator
│   ├── snapshot.ts         # orchestrates all data into one MarketSnapshot
│   ├── ai.ts               # Groq API call with structured facts payload
│   ├── validate.ts         # strict validation of AI output
│   ├── format.ts           # Telegram message templates
│   └── commands.ts         # wires intents to the pipeline above
├── scripts/
│   ├── set-webhook.js      # registers your Vercel URL with Telegram
│   └── webhook-info.js     # inspects current webhook registration
├── tests/
│   └── pure-logic.test.ts  # unit tests for structure/indicators/risk/validation
├── .env.example
├── vercel.json
├── package.json
└── tsconfig.json
```

This is a Vercel-native structure (no framework like Next.js is required —
each file under `api/` is its own serverless function), which keeps cold
starts small and avoids pulling in unused framework machinery.

---

## C. Environment Variables

See `.env.example` for the full template. Summary:

| Variable | Required | Purpose |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Yes | From @BotFather |
| `TELEGRAM_WEBHOOK_SECRET` | Recommended | Random string; Telegram echoes it back so we can reject spoofed requests |
| `TELEGRAM_ALLOWED_USER_ID` | Recommended | Your numeric Telegram user ID (comma-separated for more than one) |
| `AI_API_KEY` | Yes | Groq API key, server-side only (free tier, no card required) |
| `MARKET_DATA_API_KEY` | Yes | Twelve Data API key |
| `NEWS_API_KEY` | Optional | Finnhub API key — enables the news-risk check |

All are set as **Vercel Environment Variables** (Project → Settings →
Environment Variables), never committed to the repo, never sent to the
client, never logged.

---

## D. Telegram Setup

1. Open Telegram, message **@BotFather**.
2. `/newbot` → follow the prompts → copy the bot token.
3. Message **@userinfobot** to get your numeric Telegram user ID.
4. Put both in Vercel env vars (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_ALLOWED_USER_ID`).
5. Generate a webhook secret: `openssl rand -hex 24` → put it in
   `TELEGRAM_WEBHOOK_SECRET`.

Webhook registration happens after deployment (see section H).

---

## E. Market Data Setup — why Twelve Data

**Selected provider: [Twelve Data](https://twelvedata.com)**

- Genuinely supports `XAU/USD` (spot gold) as a first-class symbol, both for
  real-time quotes and historical OHLC candles at 1min/5min/15min/30min/1h/4h/1day —
  exactly the timeframe set this bot needs.
- Free tier (800 requests/day, 8/minute) comfortably covers **on-demand**
  personal use: one full analysis costs 6 requests (1 quote + 5 timeframes),
  so you can run well over 100 analyses a day for free.
- Plain REST/JSON over HTTPS — no SDK, no persistent connection, no
  WebSocket needed (WebSocket is free-tier "trial only" and isn't needed
  since you trigger analysis manually) — a perfect fit for a stateless
  serverless function that wakes up, makes a few `fetch()` calls, and exits.
- If Twelve Data ever returns an error, is missing a field, or the quote
  timestamp is older than 120 seconds, the bot refuses to generate a setup
  and tells you plainly instead of guessing (`lib/marketData.ts`,
  `lib/snapshot.ts`).

Indicators (EMA/RSI/MACD/ATR) are computed **locally** in `lib/indicators.ts`
from the same candle data already fetched for structure analysis, rather
than calling Twelve Data's separate indicator endpoints — this keeps every
number derived from one consistent dataset and conserves API credits.

---

## F. AI Setup — why Groq

**Selected provider: [Groq](https://console.groq.com)**

Groq has a genuinely free tier — no credit card, no expiring trial credits,
just an email signup — with fast inference on strong open-weight models
(default here: `openai/gpt-oss-120b`). For a personal bot you trigger
on-demand, the free rate limit (tens of requests/minute) is far more than
you'll ever need, since one analysis = exactly one AI call.

1. Go to console.groq.com → sign up with email (no card).
2. **API Keys → Create API Key** → name it → copy it immediately.
3. Put it in Vercel as `AI_API_KEY`.

If Groq ever changes its free-tier model lineup, swap the model with zero
code changes via the `AI_MODEL` env var (see `.env.example`).

The AI engine (`lib/ai.ts`) calls Groq's OpenAI-compatible
`/openai/v1/chat/completions` endpoint directly with your `AI_API_KEY`
(server-side only — never exposed to Telegram, logs, or the client), and
forces strict JSON output via `response_format: json_object`. The system
prompt enforces:

- It receives **only** the structured facts payload (live quote, per-timeframe
  candles/indicators/structure, news snapshot, session) — never asked to
  recall or guess a price.
- It must return a single strict JSON object matching the `TradePlan` schema
  in `lib/types.ts` — no prose, no markdown fences.
- It defaults to `WAIT` unless there's genuine multi-timeframe alignment, a
  concrete entry trigger, valid stop-loss, and acceptable risk/reward.
- It must return `NO_TRADE` (not `WAIT`) when a high-impact USD event is
  imminent or the data is questionable.
- It's explicitly forbidden from claiming trade execution or guaranteeing
  outcomes.

`lib/validate.ts` then independently re-checks the AI's output — decision
enums, required fields for BUY/SELL, and a numeric sanity check that every
proposed price is within 5% of the live quote and correctly ordered
(stop/entry/TP on the right sides for the direction). If validation fails
for any reason, the user gets "Analysis could not be validated safely.
Please try again." — the raw AI output is never forwarded unchecked.

The model is `openai/gpt-oss-120b` by default, overridable via an `AI_MODEL`
env var with no code change if you want to swap models later.

---

## G. Vercel Deployment

**Option 1 — GitHub → Vercel**
1. Push this project to a new GitHub repo (keep it private — it's a personal
   trading tool).
2. In Vercel: **New Project → Import** your repo.
3. Add the environment variables from section C.
4. Deploy. Vercel will give you a URL like `https://xauusd-bot.vercel.app`.

**Option 2 — Vercel CLI**
```bash
npm i -g vercel
vercel login
vercel            # first deploy (preview)
vercel --prod     # promote to production
```

---

## H. Webhook Setup

Once deployed, tell Telegram where to send updates:

```bash
export TELEGRAM_BOT_TOKEN=xxxxx
export TELEGRAM_WEBHOOK_SECRET=xxxxx   # same value you set in Vercel
node scripts/set-webhook.js https://your-app.vercel.app/api/telegram/webhook
```

Verify it registered correctly:
```bash
node scripts/webhook-info.js
```
Look for `"url"` matching your deployment and `"last_error_message"` absent.

---

## I. Testing

Unit tests for pure logic (no network calls) are in `tests/pure-logic.test.ts`,
covering structure detection, indicators, risk calculation, AI-output
validation (including rejecting inverted/hallucinated trade plans), and
intent/argument parsing. Run with:
```bash
npm install
npm test
```

Full manual checklist before you trust it with real decisions:

- [ ] `node scripts/webhook-info.js` shows your URL, no `last_error_message`
- [ ] `/start` replies with the welcome message
- [ ] `/help` lists all commands
- [ ] `/status` shows Telegram/AI/Market Data all 🟢
- [ ] `/gold`, `/xauusd`, `/analyze` all return a full analysis
- [ ] A plain-English message ("Should I buy or sell gold?") is understood
- [ ] The returned price matches a live gold price you check independently
      (e.g. a quick web search) within a few dollars
- [ ] Ask again immediately — confirm it's a **fresh** analysis, not a repeat
- [ ] `/risk 500 1 2650 2645` returns a sane position size and states the
      contract-size assumption
- [ ] `/news` shows upcoming events (if `NEWS_API_KEY` is set) or clearly
      says news-checking is disabled (if not)
- [ ] Temporarily set `MARKET_DATA_API_KEY` to an invalid value and confirm
      the bot says data is unavailable rather than fabricating a setup, then
      restore the correct key
- [ ] Message from a **different** Telegram account (or temporarily unset
      `TELEGRAM_ALLOWED_USER_ID` and re-set it) to confirm unauthorized users
      get "Unauthorized user."
- [ ] Confirm no `.env` file or secret ever appears in your GitHup repo or
      Vercel build logs

---

## J. Security

- All secrets (`TELEGRAM_BOT_TOKEN`, `AI_API_KEY`, `MARKET_DATA_API_KEY`,
  `NEWS_API_KEY`, `TELEGRAM_WEBHOOK_SECRET`) are Vercel **server-side**
  environment variables — never referenced in any client-side code (there is
  no client-side code; this is Telegram-only).
- The webhook verifies Telegram's `X-Telegram-Bot-Api-Secret-Token` header
  against `TELEGRAM_WEBHOOK_SECRET` on every request and rejects mismatches
  with HTTP 401, before any processing happens.
- `TELEGRAM_ALLOWED_USER_ID` blocks any Telegram user not on your allow-list
  — no user table, just an env-var comparison per request.
- Errors are logged server-side with secrets never included; user-facing
  error messages are generic and never echo raw provider responses that
  could theoretically contain sensitive data.
- The bot never logs or persists conversation content anywhere.

---

## K. Exness MT5 Limitation

This bot has **no connection whatsoever** to your Exness MT5 account. It
cannot see your balance, positions, or orders, and it cannot place, modify,
or close a trade. Every response that includes a trade plan ends with an
explicit "MANUAL EXECUTION" notice, and the `/status` command always reports:

```
Exness MT5: ⚪ NOT CONNECTED
Execution: 🔴 DISABLED
```

You are the only one who touches Exness MT5, by hand, on your iPhone.

---

## L. Future MT5 Upgrade Path

If you later get a VPS or a genuine MT5 bridge, the codebase already has a
clean seam for it: add an `lib/mt5Connector.ts` implementing the conceptual
interface —

```ts
interface MT5Connector {
  getAccountInfo(): Promise<AccountInfo>;
  getPositions(): Promise<Position[]>;
  getOrders(): Promise<Order[]>;
  getSymbolInfo(symbol: string): Promise<SymbolInfo>;
  getTick(symbol: string): Promise<Tick>;
  getRates(symbol: string, tf: Timeframe): Promise<Candle[]>;
  getHistory(...): Promise<Trade[]>;
  placeOrder(...): Promise<OrderResult>;
  modifyPosition(...): Promise<void>;
  closePosition(...): Promise<void>;
}
```

Until such a connector is actually implemented and verified, any code that
would call it should return an explicit `MT5_NOT_CONNECTED` state — never a
fabricated response — exactly as `/status` does today. Wiring it in would
mean: swap the "MANUAL EXECUTION" footer for real account/position data in
`lib/format.ts`, and optionally add an explicit confirmation step before
`placeOrder()` is ever called. No other part of the architecture (Telegram
handling, market data, AI reasoning, validation) needs to change.

---

## Notes on scope / honesty

- Market "structure" (BOS/CHOCH/swings/liquidity) is computed with a
  deterministic fractal-swing algorithm in `lib/structure.ts`, not invented
  by the AI — the AI reasons over these pre-computed facts.
- Fair Value Gap detection was intentionally left out of v1 rather than
  shipped as a rough approximation — flagging this as a natural next
  addition to `lib/structure.ts` if you want it.
- The risk calculator assumes a standard 100oz/lot XAUUSD contract (the
  common convention) since Exness's exact contract specification isn't
  something this bot can query — it says so explicitly in every risk
  calculation and tells you to confirm against MT5's own symbol
  specification before sizing a real trade.
